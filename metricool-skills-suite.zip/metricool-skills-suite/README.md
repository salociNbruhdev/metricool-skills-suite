# Metricool Claude Skills Suite

Conjunto modular de sete skills para Claude: coleta de dados do Metricool, diagnóstico de desempenho, inteligência competitiva, estratégia de conteúdo, planejamento semanal e relatórios em PDF.

## Instalação rápida

### Opção A — Claude Code (instalar as 7 skills de uma vez)

No Claude Code, execute:

```text
/plugin marketplace add SEU_USUARIO/metricool-claude-skills
/plugin install metricool-suite@metricool-claude-marketplace
```

Substitua `SEU_USUARIO` pelo seu usuário ou organização do GitHub. Depois, reinicie/atualize a sessão se necessário.

### Opção B — Claude.ai (upload de skills)

O Claude.ai não instala skills diretamente de um repositório GitHub. Baixe os ZIPs individuais em [`individual-skill-zips/`](individual-skill-zips/) e envie cada ZIP em **Customize → Skills → + Create skill → Upload a skill**. Ative as sete skills após o upload.

> Cada ZIP individual já deve conter a pasta da skill na raiz do arquivo compactado. Não envie o ZIP deste repositório inteiro como se fosse uma única skill.

## As sete skills

1. **Metricool Command Center** — skill-mãe que coordena o uso dos módulos.
2. **Data Collection** — coleta e organiza métricas disponíveis.
3. **Performance Diagnostics** — identifica resultados, padrões e gargalos.
4. **Competitor Intelligence** — benchmarking de concorrentes e análise comparativa.
5. **Content Strategy** — transforma dados em decisões estratégicas.
6. **PDF Report** — prepara relatórios profissionais em PDF.
7. **Weekly Planner** — cria o planejamento semanal com o que repetir, corrigir, testar e interromper.

## Conectar ao Metricool

Configure o MCP oficial do Metricool no Claude, seguindo a documentação atual do Metricool: https://help.metricool.com/
As skills não contêm credenciais. Nunca publique tokens, senhas ou chaves de API neste repositório.

## Estrutura

- `skills/`: fontes das sete skills para Claude.ai e revisão.
- `individual-skill-zips/`: arquivos ZIP individuais para Claude.ai.
- `plugins/metricool-suite/`: plugin agrupado para Claude Code.
- `.claude-plugin/marketplace.json`: catálogo para instalação via marketplace no Claude Code.

## Prioridade de qualidade

As instruções priorizam precisão, validação, profundidade e qualidade da entrega em vez de velocidade. O Claude deve distinguir dados observados de hipóteses, não inventar métricas e explicitar limitações de acesso.
