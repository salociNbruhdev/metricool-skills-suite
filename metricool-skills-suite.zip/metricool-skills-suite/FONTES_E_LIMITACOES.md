# Fontes oficiais e premissas técnicas

Documentação consultada em 9 de novembro de 2026. Os detalhes de produto podem mudar; Claude deve confirmar a disponibilidade real no ambiente antes de executar.

1. **Como conectar o MCP do Metricool ao Claude**  
   https://help.metricool.com/pt/como-conectar-o-mcp-do-metricool-ao-claude-0l84v  
   Compatibilidade com Claude.ai/Desktop/Code, conexão OAuth, URL oficial e capacidades do MCP.

2. **Limites do MCP e requisitos do plano**  
   https://help.metricool.com/pt/limites-do-mcp-e-requisitos-do-plano-h72jg  
   Histórico do plano Free, requisitos, diferenças entre MCP e API e limitações de recursos.

3. **MCP vs. acesso à API**  
   https://help.metricool.com/pt/mcp-vs-acesso-a-api-qual-e-a-diferenca-5y3ib  
   Quando usar MCP ou API e quais áreas o MCP disponibiliza.

4. **Análise de concorrentes**  
   https://help.metricool.com/pt/analise-de-concorrentes-ouhue  
   Disponibilidade por rede, natureza orgânica dos dados, janelas históricas e diferenças metodológicas de engagement.

5. **Como criar custom skills no Claude**  
   https://support.claude.com/en/articles/12512198-how-to-create-custom-skills  
   Estrutura de pastas, `SKILL.md`, metadados e upload via ZIP.

6. **Usar skills no Claude**  
   https://support.claude.com/en/articles/12512180-use-skills-in-claude  
   Processo de upload e ativação de skills personalizadas.

## Premissas

- O conector oficial MCP é preferencial para consultas de analytics em Claude.
- API REST é alternativa, não pré-requisito, e depende do plano Metricool Advanced ou Custom.
- A disponibilidade efetiva de métricas é determinada pela conexão, rede e plano; não se assume um esquema universal.
- Os dados dos concorrentes são observações públicas/orgânicas quando fornecidos pelo módulo de concorrentes do Metricool. O cálculo de engagement de concorrentes pode usar seguidores como denominador, diferentemente da conta própria.
- Skills são instruções modulares. A skill-mãe orienta Claude a selecionar os módulos; o acionamento concreto depende do mecanismo de skills/ambiente habilitado e da correspondência das descrições.
