# Instalação rápida

## Claude Code

1. Publique a raiz deste projeto em um repositório GitHub público.
2. No Claude Code, rode `/plugin marketplace add SEU_USUARIO/metricool-claude-skills`.
3. Rode `/plugin install metricool-suite@metricool-claude-marketplace`.
4. As sete skills ficam disponíveis como parte do plugin.

## Claude.ai

1. Abra `individual-skill-zips/`.
2. Baixe os sete ZIPs, um por vez.
3. Em Claude.ai, vá a Customize → Skills → + Create skill → Upload a skill.
4. Envie cada ZIP e ative as sete skills.

Claude.ai não oferece, no fluxo normal de skills personalizadas, instalação direta por URL de repositório GitHub.
