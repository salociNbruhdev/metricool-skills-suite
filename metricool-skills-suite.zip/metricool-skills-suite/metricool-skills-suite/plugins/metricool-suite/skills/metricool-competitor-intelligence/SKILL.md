---
name: metricool-competitor-intelligence
description: Compara as contas do usuário com concorrentes no Metricool e pesquisa sinais públicos do setor, distinguindo benchmarks comparáveis de evidências qualitativas.
---

# Inteligência competitiva para redes sociais

## Objetivo

Descobrir o que os concorrentes fazem bem, onde existe espaço para diferenciação e quais práticas merecem ser testadas. Priorize concorrentes já cadastrados no Metricool e não fabrique dados privados ou históricos que não existem.

## Prioridade de qualidade

- Compare contas da mesma plataforma e, sempre que possível, com objetivos, idioma, público e porte semelhantes.
- Registre período, data de consulta, tamanho da amostra e origem de cada evidência.
- Diferencie métricas nativas do Metricool de observações obtidas em pesquisa pública.
- Não conclua que uma tática funciona apenas porque um concorrente a usa.

## 1. Fontes e ordem de preferência

1. Concorrentes já cadastrados no Metricool e dados retornados pelo MCP.
2. Publicações públicas acessíveis nos perfis oficiais dos concorrentes.
3. Sites, páginas oficiais e outras fontes abertas confiáveis para contexto de posicionamento.

Não tente acessar contas privadas, áreas restritas, mensagens privadas ou dados que exijam autorização alheia. Se o Metricool não tiver concorrentes configurados, informe isso e use pesquisa pública complementar apenas quando houver mecanismo de busca/navegação disponível.

## 2. Disponibilidade e limitações do Metricool

Considere os limites documentados:

- A análise de concorrentes está disponível no Free e em planos pagos para Facebook, Instagram, Threads, Bluesky e Twitch.
- YouTube e X dependem de planos pagos; X também exige o complemento indicado pelo Metricool.
- Atualmente, o recurso não cobre outras redes além das listadas.
- O histórico de posts começa, em regra, no dia 1 do mês anterior ao momento em que o concorrente é conectado. Em planos pagos, pode ser possível solicitar sincronização de até 300 posts, dependendo da API e da plataforma.
- Dados de concorrentes são orgânicos.
- Seguidores e gostos só podem ser monitorados a partir da conexão; não há histórico anterior à adição.
- O engagement de concorrentes usa seguidores como denominador, porque alcance não é público. O engagement do perfil próprio pode usar alcance. Portanto, não compare essas taxas diretamente como se fossem a mesma fórmula.
- Métricas e disponibilidade variam por plataforma. No Threads existem especificações próprias e limitações de lista de publicações/estatísticas.
- Likes ocultos no Instagram podem aparecer sem contagem explícita.

Nunca tente contornar limites do plano ou inventar dados históricos.

## 3. Montagem do benchmark

Para cada concorrente e plataforma, registre:

- Nome e identificador/perfil oficial.
- Por que é comparável: nicho, produto, público, região, porte ou formato.
- Métricas disponíveis e período efetivo.
- Número de publicações da amostra.
- Frequência de publicação.
- Interações médias por post e distribuição, quando disponíveis.
- Engagement e definição exata do denominador.
- Crescimento e evolução apenas quando o período de monitoramento permitir.
- Conteúdos de destaque e links.

Se possível, inclua três grupos:

1. Concorrentes diretos: oferta e público próximos.
2. Concorrentes de atenção: criadores/canais que disputam o mesmo tempo e interesse da audiência.
3. Referências aspiracionais: perfis maiores ou com execução editorial especialmente forte.

Não apresente perfis aspiracionais como concorrentes diretos sem justificativa.

## 4. Análise qualitativa de conteúdo

Examine uma amostra recente e relevante de publicações públicas. Classifique:

- Temas e pilares editoriais.
- Formatos e duração.
- Frequência e cadência.
- Ganchos, títulos, capas e thumbnails.
- Estrutura de roteiro e storytelling.
- CTAs e propostas de valor.
- Séries recorrentes e campanhas.
- Comentários/reação pública visível apenas quando legal e tecnicamente acessível.
- Padrões de apresentação visual e posicionamento.

Identifique padrões replicáveis como princípios, não copie roteiros, identidade visual ou textos. O objetivo é aprender, adaptar e diferenciar.

## 5. Lacunas e oportunidades

Responda:

- Em quais métricas o usuário está atrás, à frente ou sem dados suficientes?
- Quais formatos ou temas aparecem com frequência nos concorrentes e estão ausentes no perfil do usuário?
- Que necessidades da audiência parecem pouco atendidas?
- Que ângulos ainda estão subexplorados?
- O que o usuário pode fazer de forma diferente para não virar uma cópia tardia?

Classifique cada oportunidade por impacto potencial, confiança, esforço e risco de imitação genérica.

## 6. Formato da saída

Inclua:

- Matriz de concorrentes, com fonte, rede, período e métricas comparáveis.
- Comparação quantitativa com ressalvas metodológicas.
- 3 a 5 padrões de conteúdo observados.
- Oportunidades concretas de diferenciação.
- Recomendações para testes, com hipótese e métrica de sucesso.
- Dados indisponíveis e limites da amostra.

Se não houver concorrentes cadastrados e a pesquisa externa não estiver disponível, não improvise uma análise. Entregue a estrutura de comparação e explique o passo necessário: adicionar concorrentes na seção Analytics > Competitors do Metricool ou fornecer perfis de referência.
