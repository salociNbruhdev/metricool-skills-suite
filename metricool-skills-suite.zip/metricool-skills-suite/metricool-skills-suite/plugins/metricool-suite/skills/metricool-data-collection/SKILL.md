---
name: metricool-data-collection
description: Consulta e organiza marcas, redes sociais, métricas, publicações e períodos disponíveis no Metricool, verificando cobertura e qualidade dos dados.
---

# Coleta e inventário de dados do Metricool

## Objetivo

Obter uma base consistente e auditável dos dados disponíveis na conta Metricool do usuário. A coleta deve ser ampla, organizada por marca e plataforma, e deve preservar a origem e as limitações de cada métrica.

## Prioridade de execução

**Qualidade acima da velocidade.** Faça um inventário antes de extrair. Consulte novamente dados inconsistentes. Não pare na primeira visão geral. Não invente métricas que uma rede não fornece.

## Fonte de dados preferencial

1. Use o conector oficial MCP do Metricool já autorizado no Claude.
2. Verifique as ferramentas efetivamente expostas pelo MCP e use os nomes/argumentos reais disponíveis. Não invente nomes de ferramentas nem endpoints.
3. Não solicite API key se o OAuth do MCP estiver conectado.
4. A API REST é alternativa apenas quando o usuário possui acesso e a integração é necessária. A API tradicional do Metricool está restrita aos planos Advanced e Custom; não confunda isso com o MCP, que funciona em qualquer plano, sujeito aos limites do plano.
5. Navegação pela interface ou exportação manual é alternativa de contingência, sempre declarando a origem.

## Etapa 1 — Inventário

- Liste todas as marcas às quais a conta conectada dá acesso.
- Para cada marca, identifique as redes e contas conectadas.
- Registre contas conectadas, desconectadas, com erro ou sem dados.
- Identifique categorias disponíveis: visão geral, evolução de seguidores, alcance, impressões/visualizações, interações, engagement, cliques, visitas, dados demográficos, publicações, stories, Reels, vídeos, anúncios e horários, conforme a plataforma e a ferramenta realmente disponibilizarem.
- Consulte quais métricas existem antes de construir pedidos de dados. Não pressuponha que todos os perfis tenham os mesmos campos.
- Identifique concorrentes configurados e as redes onde a comparação existe.
- Registre se há analytics de contas de anúncios conectadas. O MCP permite consultar analytics de anúncios conectados, mas não administrar campanhas da aba Anúncios.

## Etapa 2 — Definição de período

Use, quando disponíveis:

- Período principal: últimos 90 dias completos ou o maior intervalo recente e consistente disponível.
- Contexto de tendência: últimos 12 meses, se o plano e a plataforma permitirem.
- Comparação: período imediatamente anterior com duração equivalente.
- Conteúdo recente: janela suficiente para comparar posts com tempo de maturação semelhante.

Se o plano só disponibilizar 30 dias, use esse intervalo e informe claramente. Não finja possuir 90 dias. Registre as datas inicial e final efetivamente retornadas, não apenas o período solicitado.

## Etapa 3 — Coleta por rede

Para cada marca e rede, colete o conjunto mais completo possível de dados agregados e por publicação. Priorize os dados realmente disponíveis, incluindo, quando presentes:

- Seguidores/subscritores e variação líquida.
- Alcance, impressões, visualizações e visualizações de vídeo.
- Curtidas, comentários, compartilhamentos, salvamentos, respostas e outras interações.
- Engagement e a forma de cálculo/denominador, se exposta.
- Cliques, visitas ao perfil, visitas ao site e conversões, quando disponíveis.
- Publicações realizadas, frequência, datas/horários e formatos.
- Desempenho individual por publicação, Reel, Short, vídeo, story ou outro formato.
- Indicadores de retenção, tempo de exibição, conclusão e inscritos gerados, quando disponíveis.
- Distribuição de audiência e demografia, quando disponível e relevante.
- Dados de anúncios separados dos dados orgânicos.
- Recomendações de melhor horário do Metricool, se a função existir para a conta.

Não force a presença de uma métrica ausente. Marque-a como "não disponível" e não como zero.

## Etapa 4 — Integridade e normalização

Para cada extração, registre:

- Marca e perfil.
- Plataforma.
- Data/hora de coleta e fuso, se conhecido.
- Intervalo efetivo de dados.
- Nome original da métrica e unidade.
- Valor, contagem de registros e granularidade.
- Fonte: Metricool MCP, API ou exportação/interface.
- Observações e limitações conhecidas.

Valide:

1. Datas e janelas consistentes.
2. Ausência de duplicação de publicações.
3. Valores nulos versus zeros.
4. Mudanças de nomenclatura de métricas (por exemplo, impressões versus visualizações) sem juntá-las automaticamente.
5. Totais versus médias por publicação.
6. Dados orgânicos versus pagos.
7. Métricas de alcance versus métricas baseadas em seguidores.
8. Outliers evidentes e posts com tempo de vida muito diferente.

Se houver exportações CSV ou dados tabulares, preserve uma cópia bruta sem alteração e trabalhe em uma versão derivada. Não descarte colunas desconhecidas sem examiná-las.

## Etapa 5 — Entregável de coleta

Produza uma matriz de cobertura com colunas:

| Marca | Plataforma | Conta | Período disponível | Período coletado | Métricas disponíveis | Dados por post? | Lacunas |

Depois organize a base por plataforma e por marca. O módulo de diagnóstico deve receber os dados brutos ou uma representação fiel que mantenha os denominadores e as datas.

## Restrições e limites conhecidos

- O MCP oficial é compatível com Instagram, TikTok, LinkedIn, Facebook, X, YouTube, Pinterest, Threads, Bluesky e Twitch, além de analytics de plataformas de anúncios suportadas. A disponibilidade exata depende das contas conectadas e do plano.
- O Free do Metricool tem 30 dias de histórico de analytics, de acordo com a documentação de limites; outros planos podem oferecer histórico maior.
- O MCP não disponibiliza atualmente Inbox/comentários de posts, SmartLinks, avaliações do Google Business Profile, autolistas, arquivos do Canva/Drive ou gerenciamento de campanhas da aba Anúncios. Analytics de contas de anúncios conectadas podem estar disponíveis.
- A API REST do Metricool exige plano Advanced ou Custom.
- Não compartilhe credenciais ou tokens no relatório.

## Modo de falha

Se não houver conexão MCP, não simule coleta. Informe que a conexão precisa ser feita pelo usuário em Claude > Settings/Configurações > Connectors/Conectores > Explore connectors/Explorar conectores > Metricool > Connect. Após autorização OAuth, repita a verificação. Se uma rede falhar, continue nas demais e marque a cobertura parcial.
