---
name: metricool-content-strategy
description: Converte a análise do Metricool em estratégia editorial, prioridades, experimentos e calendário de conteúdo orientado por resultados reais.
---

# Estratégia de conteúdo orientada por dados

## Missão

Converter os achados de desempenho e concorrência em um plano concreto de melhoria. Toda recomendação deve estar ligada a um dado, a uma observação qualitativa ou a uma hipótese claramente identificada.

## Regra principal

Qualidade acima da velocidade. Não produza um calendário genérico antes de entender os dados. Não recomende postar mais como solução automática. Investigue primeiro o que merece ser repetido, corrigido, interrompido ou testado.

## 1. Transformar diagnóstico em decisões

Classifique cada achado em uma destas decisões:

- **Repetir e ampliar:** formato/tema com evidência consistente de bom resultado.
- **Otimizar:** existe sinal de potencial, mas um componente parece limitar o resultado.
- **Testar:** hipótese plausível sem evidência suficiente.
- **Reduzir ou interromper:** esforço recorrente com desempenho fraco e amostra adequada.
- **Explorar:** oportunidade observada na audiência ou concorrência ainda não testada.

Não transforme um único post viral em uma regra editorial permanente. Dê preferência a padrões repetidos e resultados acima da mediana.

## 2. Construir pilares editoriais

Defina de 3 a 5 pilares, cada um com:

- Objetivo de negócio/editorial.
- Necessidade ou interesse da audiência.
- Evidência de desempenho ou justificativa de teste.
- Formatos adequados por plataforma.
- Exemplos de pautas originais.
- CTA compatível com o objetivo.
- Métrica principal e métricas secundárias.

Evite pilares vagos como "engajamento" ou "conteúdo de valor". O pilar deve representar um assunto/abordagem editorial concreta.

## 3. Plano de experimentos

Para cada teste, especifique:

1. Hipótese verificável.
2. Variável principal (gancho, duração, formato, tema, thumbnail, CTA, horário etc.).
3. O que ficará constante para permitir comparação.
4. Quantidade mínima de tentativas ou janela de avaliação razoável.
5. Métrica primária e métricas de proteção.
6. Critério de sucesso, fracasso ou necessidade de nova amostra.
7. Próxima decisão após o teste.

Não mude várias variáveis de uma vez quando a meta for descobrir qual alteração produziu diferença.

## 4. Plano de ação priorizado

Use uma matriz simples:

| Prioridade | Ação | Evidência | Impacto potencial | Esforço | Confiança | Métrica de sucesso |

Priorize pelo potencial de impacto e pela confiança da evidência, considerando o custo. Não invente projeções numéricas de crescimento. Use intervalos ou metas provisórias apenas se forem justificáveis pela linha de base e identificadas como metas, não previsões.

## 5. Calendário semanal e mensal

Quando os dados forem suficientes, elabore um calendário de 30 dias (ou semanal, quando solicitado) com:

- Dia/data.
- Plataforma.
- Pilar/tema.
- Formato.
- Ideia original ou ângulo.
- Gancho inicial.
- Objetivo da publicação.
- CTA.
- Indicador que será acompanhado.
- Dependências de produção.

A frequência recomendada deve considerar a capacidade de produção e o desempenho observado. Se a capacidade do usuário não estiver informada, apresente uma versão mínima viável e uma versão expandida, sem assumir disponibilidade ilimitada.

Adapte uma ideia entre plataformas somente quando fizer sentido. Não recomende copiar e colar o mesmo conteúdo em todos os canais sem adaptar linguagem, duração, proporção, título e CTA.

## 6. Horários e frequência

Use primeiro os dados e recomendações do Metricool, se disponíveis. Compare com o desempenho real do perfil. Horários são hipóteses operacionais, não garantias. Se a amostra for pequena, recomende testes distribuídos por horários/dias em vez de declarar um horário ideal.

## 7. Revisão contínua

Defina um ciclo de revisão semanal:

- O que foi publicado?
- Quais conteúdos superaram a mediana e por quê?
- Quais ficaram abaixo e o que pode explicar?
- O que foi aprendido nos testes?
- O que será repetido, otimizado, interrompido ou testado na semana seguinte?

Não julgue um conteúdo antes de uma janela adequada de maturação para aquela plataforma.

## Saída estratégica

Entregue uma estratégia concisa e executável com:

1. Posicionamento e objetivos prioritários identificados nos dados.
2. Pilares editoriais.
3. Ações priorizadas.
4. Experimentos e critérios de avaliação.
5. Calendário de 30 dias ou semanal.
6. Indicadores de acompanhamento.
7. Rotina de revisão e decisão.

Cada recomendação importante deve apontar para a evidência que a originou. Onde não houver evidência, rotule como hipótese a validar.
