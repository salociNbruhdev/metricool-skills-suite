---
name: metricool-pdf-report
description: Produz relatórios executivos em PDF a partir de dados e análises do Metricool, com gráficos, tabelas, recomendações, referências e validação do arquivo final.
---

# Produção de relatório PDF do Metricool

## Objetivo

Produzir um relatório profissional, visualmente consistente e tecnicamente correto que documente a auditoria das redes sociais. O resultado obrigatório é um **arquivo PDF real**, não apenas texto dizendo que o relatório foi feito.

## Prioridade

Qualidade acima da velocidade. Não sacrifique legibilidade, consistência numérica, fontes ou validação para terminar rapidamente. Reserve tempo de execução para revisar cálculos, gráficos e paginação.

## 1. Pré-requisitos

Antes de diagramar, confirme que recebeu:

- Inventário de marcas, redes, contas e períodos.
- Matriz de cobertura e lacunas.
- Dados e análises por plataforma.
- Diagnóstico do que funciona e não funciona.
- Análise de concorrentes, quando disponível.
- Recomendações e plano de ação.
- Planejamento semanal, se solicitado ou produzido pela skill `metricool-weekly-planner`.
- Data/hora da extração e fontes.

Se faltar um módulo, registre a ausência e não invente conteúdo para preencher páginas.

## 2. Estrutura sugerida do relatório

1. Capa: título, marca/conta, período analisado e data de geração.
2. Resumo executivo: principais descobertas e decisões recomendadas.
3. Escopo e metodologia: fontes, redes, datas, definições, critérios de comparação.
4. Cobertura e qualidade dos dados: o que foi analisado e o que ficou indisponível.
5. Visão geral de desempenho: evolução e indicadores por rede.
6. Diagnóstico por plataforma: tendências, pontos fortes e pontos fracos.
7. Análise de conteúdo: melhores/mais fracos, formatos, temas, horários e frequência.
8. Concorrentes: comparação quantitativa e qualitativa, com ressalvas.
9. Oportunidades estratégicas e prioridades.
10. Plano de ação de 30 dias e experimentos.
11. Planejamento semanal: o que repetir, otimizar, testar, reduzir/pausar e explorar; calendário por plataforma; prioridades e critérios de avaliação.
12. Métricas de acompanhamento e rotina de revisão.
13. Apêndice: definições, cálculos, fontes, limitações e links dos conteúdos destacados.

Ajuste a quantidade de páginas ao volume de dados. Não force uma seção que não tenha evidência disponível.

## 3. Diretrizes visuais

- Layout editorial limpo, hierarquia clara e espaçamento consistente.
- Use gráficos de linha para evolução, barras para comparações e tabelas para detalhes.
- Identifique claramente plataforma, unidade, período e denominador.
- Evite gráficos 3D, escalas enganosas e excesso de cores.
- Não misture várias plataformas em gráficos se as métricas não forem comparáveis.
- Inclua anotações para mudanças importantes e limitações.
- Destaque poucos números decisivos; não transforme o relatório em um despejo de tabelas.
- Use fontes legíveis e contraste suficiente; repita cabeçalhos de tabelas longas quando possível.
- Inclua número de página e identificação do relatório.
- Mantenha links/permalinks clicáveis quando viável.

## 4. Precisão e transparência

- Todo número exibido precisa corresponder à base recebida ou a um cálculo reproduzível.
- Rotule métricas derivadas e forneça a fórmula no apêndice quando relevante.
- Distingua contagens, taxas, médias e medianas.
- Sempre inclua o tamanho da amostra para rankings de publicações.
- Não apresente dados de concorrentes como se fossem privados; são observações públicas e podem ter limitações de cobertura.
- Não compare engagement próprio baseado em alcance com engagement concorrente baseado em seguidores como equivalentes.
- Separe dados orgânicos de dados pagos.
- Registre períodos diferentes por rede quando isso ocorrer.
- Inclua nota de que ausência de dado não significa valor zero.

## 5. Geração do PDF

Use as ferramentas de criação de arquivos disponíveis no ambiente Claude. Prefira uma solução que permita controle sobre gráficos, tabelas, fontes e paginação (por exemplo, ReportLab ou HTML/CSS convertido para PDF, conforme bibliotecas e ferramentas disponíveis). Não assuma que uma biblioteca está instalada: verifique antes.

Se usar Python:

1. Mantenha dados brutos separados dos dados formatados.
2. Gere gráficos a partir dos dados conferidos.
3. Use funções reutilizáveis para cabeçalhos, rodapés, tabelas e páginas.
4. Trate textos longos, quebras de linha e tabelas que atravessam páginas.
5. Use nomes de arquivos claros e sem caracteres problemáticos.

Se uma ferramenta de PDF nativa estiver disponível, ela pode ser usada desde que o arquivo final seja verificável.

## 6. Validação obrigatória antes da entrega

- Confirme que o PDF existe e tem tamanho maior que zero.
- Abra/inspecione o PDF por meio de ferramenta disponível ou extraia seu texto para conferir conteúdo.
- Confira todas as páginas, especialmente tabelas e gráficos que podem ter sido cortados.
- Verifique se títulos, legendas, datas e fontes estão legíveis.
- Verifique se totais e percentuais batem com as bases.
- Confira se os links funcionam, quando possível.
- Verifique se não há páginas vazias, textos sobrepostos, símbolos quebrados ou trechos fora da margem.
- Se encontrar problemas, corrija e gere novamente. Não entregue a primeira renderização sem revisão.

## 7. Entrega

Salve o arquivo em uma pasta acessível para download no ambiente e forneça o link/anexo real do PDF. Use um nome como `relatorio-metricool-auditoria-AAAA-MM-DD.pdf`.

Na conversa, inclua uma síntese com as principais descobertas, informe a cobertura e as limitações relevantes e apresente o PDF. Se não for tecnicamente possível gerar ou validar o PDF, diga isso claramente e entregue o conteúdo estruturado como contingência, sem afirmar que um PDF existe.
