---
name: metricool-weekly-planner
description: Cria planejamento semanal de conteúdo orientado pelos dados do Metricool, identificando o que repetir, otimizar, testar, reduzir e explorar em cada rede social.
---

# Planejamento semanal orientado por dados

## Missão

Transformar os dados reais do Metricool, o diagnóstico de desempenho e as oportunidades observadas na concorrência em um plano semanal de conteúdo que possa ser executado. O plano deve explicar **o que publicar, por que publicar, onde, quando, com qual abordagem e como avaliar o resultado**.

A prioridade é **qualidade acima da velocidade**. Investigue, confira e raciocine antes de montar o calendário. Não preencha a semana com ideias genéricas apenas para entregar muitos posts.

## Quando acionar esta skill

Use esta skill quando o usuário pedir planejamento semanal, calendário da semana, ideias para os próximos dias, plano de publicações, revisão da semana ou uma rotina recorrente de conteúdo. Acione-a também como etapa de uma auditoria geral do Metricool, depois de coletar e diagnosticar os dados e, quando disponíveis, analisar os concorrentes.

Se os dados ainda não tiverem sido coletados, solicite/execute primeiro `metricool-data-collection` e `metricool-performance-diagnostics`. Use `metricool-competitor-intelligence` quando houver concorrentes cadastrados ou quando a comparação for relevante. Consulte `metricool-content-strategy` para alinhar o plano aos pilares, objetivos e experimentos estratégicos existentes.

## Princípios obrigatórios

1. **Evidência antes de opinião:** vincule as decisões a métricas, publicações identificáveis, padrões observados ou hipóteses claramente rotuladas.
2. **Qualidade acima da velocidade:** não entregue um calendário superficial apenas para responder rápido. Verifique dados, amostras, períodos e consistência entre plataformas.
3. **Não invente dados:** não crie métricas, tendências, horários ideais, desempenho de concorrentes, capacidade de produção ou resultados esperados.
4. **Não confunda correlação com causa:** um post bem-sucedido em certo horário, formato ou tema não prova sozinho que esse fator causou o resultado.
5. **Não supervalorize exceções:** um único viral não deve definir a estratégia. Procure padrões repetidos e compare com medianas e amostras adequadas.
6. **Personalize por plataforma:** adapte formato, gancho, duração, título, legenda, CTA e frequência às características e aos dados de cada rede. Não replique o mesmo conteúdo sem adaptação.
7. **Respeite capacidade realista:** não presuma que o usuário consegue produzir em escala ilimitada. Se a capacidade não estiver registrada, apresente um plano essencial e identifique claramente qualquer premissa de volume.
8. **Sem publicação automática:** esta skill planeja e recomenda. Não crie, edite, agende, publique ou exclua posts no Metricool sem solicitação explícita e confirmação específica do usuário.

## Etapa 1 — Definir o escopo da semana

- Identifique as marcas, perfis e redes que serão incluídos.
- Use a semana solicitada pelo usuário. Se ele disser apenas “esta semana” ou “próxima semana”, confirme a data atual no ambiente e apresente datas absolutas.
- Considere segunda-feira a domingo como organização padrão, salvo preferência diferente do usuário.
- Use o fuso horário da conta ou do usuário quando estiver disponível. Se não estiver, não invente horários exatos.
- Identifique objetivos atuais, campanhas, lançamentos, datas importantes e restrições já conhecidas. Não invente compromissos ou eventos.

## Etapa 2 — Coletar e validar a base de decisão

Consulte, conforme a disponibilidade do Metricool:

- Publicações e resultados das últimas 4 a 8 semanas completas, ou o maior histórico confiável disponível.
- Resultados dos últimos 7 dias, sem ignorar o tempo de maturação dos conteúdos.
- Comparação com a semana anterior e, quando possível, com a mediana do período de referência.
- Desempenho por rede, formato, tema/pilar, frequência, horário, duração, gancho e CTA, quando esses campos existirem.
- Indicadores alinhados ao objetivo: alcance, impressões, visualizações, retenção/tempo assistido, interações, compartilhamentos, salvamentos, cliques, visitas, seguidores ganhos e conversões, conforme a plataforma disponibilizar.
- Conteúdos publicados, agendados ou em rascunho no Planner, se o conector permitir consultar esses dados.
- Concorrentes cadastrados e sinais públicos relevantes, se acessíveis.

Antes de interpretar:

- Registre período, data/hora da extração, rede, perfil e fonte.
- Verifique se os períodos comparados têm duração equivalente.
- Separe posts recentes de posts que já tiveram tempo suficiente para acumular resultados.
- Mostre quantidade de publicações e tamanho da amostra.
- Use medianas quando poucos conteúdos de desempenho extremo distorcerem médias.
- Não compare diretamente taxas de redes diferentes sem explicar definições e denominadores.
- Registre campos ausentes, falhas de acesso e limitações do plano.

Se não houver amostra suficiente, ainda monte um plano provisório baseado no que for verificável, mas rotule as decisões como hipóteses e indique o que precisa ser testado. Nunca simule uma análise completa.

## Etapa 3 — Fazer a revisão do que funcionou e do que não funcionou

Classifique os aprendizados por perfil e plataforma:

### Funcionou — repetir e ampliar

Identifique os temas, formatos, abordagens, ganchos e CTAs que apresentaram resultados consistentes acima da referência do próprio perfil. Traga exemplos concretos de publicações e os indicadores que justificam a decisão.

### Funcionou parcialmente — otimizar

Mostre conteúdos com sinais positivos, mas com gargalos possíveis. Exemplos: bom alcance e baixa retenção; boa retenção e poucos cliques; muitas visualizações e poucas interações qualificadas. Recomende uma alteração por vez para descobrir o que melhora o resultado.

### Não funcionou — reduzir ou interromper

Identifique padrões abaixo da referência, considerando amostra, maturação, objetivo e contexto. Explique o que pode ser reduzido, reformulado ou interrompido. Não classifique um post isolado como fracasso definitivo sem evidência suficiente.

### Ainda não sabemos — testar

Apresente hipóteses novas com variável e critério de avaliação. Diga claramente que ainda não existe evidência suficiente.

### Oportunidades — explorar

Inclua perguntas da audiência, lacunas de conteúdo, formatos subutilizados e oportunidades competitivas verificáveis. Use concorrentes como referência de oportunidade, nunca como conteúdo para copiar.

## Etapa 4 — Priorizar a semana

Monte uma lista curta e ordenada de prioridades. Considere:

- Contribuição para o objetivo principal da conta.
- Força e consistência da evidência.
- Potencial de impacto.
- Esforço de produção e recursos disponíveis.
- Necessidade de diversificar testes sem abandonar o que já funciona.
- Oportunidades e riscos específicos de cada plataforma.

Use as categorias **Repetir**, **Otimizar**, **Testar**, **Reduzir/pausar** e **Explorar**. Não imponha percentuais fixos de conteúdo por categoria. A distribuição deve decorrer dos dados e da capacidade de execução.

## Etapa 5 — Montar o calendário semanal

Crie um calendário por perfil e plataforma, de segunda a domingo (ou conforme a semana escolhida), incluindo apenas dias de publicação que façam sentido. Para cada publicação planejada, informe:

| Campo | O que registrar |
|---|---|
| Data/dia | Data absoluta e dia da semana |
| Plataforma/perfil | Conta exata onde será publicado |
| Decisão | Repetir, otimizar, testar ou explorar |
| Pilar/tema | Assunto editorial específico |
| Ideia/ângulo | O que o conteúdo vai entregar, sem ser genérico |
| Formato | Reel, Short, carrossel, vídeo longo, story, post etc., conforme a rede |
| Gancho | Primeira frase/cena ou promessa central |
| Estrutura | Roteiro resumido, sequência de tópicos ou composição |
| CTA | Ação desejada, coerente com o objetivo |
| Horário | Apenas quando houver evidência; caso contrário, indicar janela de teste ou “a definir” |
| Métrica principal | Indicador para avaliar o conteúdo |
| Produção | Materiais, gravação, edição ou dependências necessárias |

Não é obrigatório publicar todos os dias. Se a frequência atual não estiver funcionando, não a mantenha por inércia. Se a frequência recomendada exceder a capacidade conhecida, reduza e explique a escolha.

Para cada ideia, inclua detalhe suficiente para ser produzida. Evite títulos vagos como “dica”, “curiosidade”, “post de engajamento” ou “fale sobre tecnologia”. Prefira uma promessa editorial específica, uma pergunta concreta, uma comparação ou um problema real da audiência.

## Etapa 6 — Detalhar a execução

Depois do calendário, inclua:

- **Top 3 prioridades da semana:** o que não pode ficar de fora e por quê.
- **Briefs dos conteúdos principais:** gancho, sequência/roteiro, pontos-chave, CTA e adaptação por plataforma.
- **Lista de produção:** o que precisa ser pesquisado, roteirizado, gravado, editado, revisado e preparado.
- **Plano alternativo:** o que publicar ou ajustar se uma produção atrasar, sem inventar ativos já disponíveis.
- **Testes da semana:** hipótese, variável única prioritária, amostra/janela de observação, métrica principal e critério de decisão.

Evite mudar várias variáveis simultaneamente em um teste. Quando o objetivo for comparar ganchos, por exemplo, mantenha o restante do conteúdo tão consistente quanto for viável.

## Etapa 7 — Definir como avaliar a semana

Para cada prioridade ou teste, defina:

- Linha de base observada no perfil.
- Indicador principal e indicadores de proteção.
- Janela adequada de avaliação por plataforma.
- Critério de sucesso, fracasso ou necessidade de mais dados.
- Decisão prevista: repetir, otimizar, pausar ou testar novamente.

Não prometa crescimento nem invente metas percentuais. Metas numéricas só podem ser propostas quando forem justificadas pela linha de base; identifique-as como metas operacionais, nunca como previsão garantida.

## Formato obrigatório da resposta

Entregue nesta ordem:

1. **Resumo da semana:** período, perfis incluídos e objetivo prioritário.
2. **Diagnóstico rápido:** o que funcionou, o que não funcionou, o que precisa melhorar e o que ainda é hipótese.
3. **Prioridades:** ações ordenadas por importância e justificadas por evidências.
4. **Calendário semanal:** tabela detalhada por dia, perfil e plataforma.
5. **Briefs e produção:** roteiros/resumos dos principais conteúdos e tarefas necessárias.
6. **Testes e métricas:** o que será medido, quando e como decidir.
7. **Riscos e limitações:** dados faltantes, amostras pequenas, conteúdo ainda imaturo e capacidade presumida.
8. **Checklist de revisão no fim da semana:** o que comparar e quais decisões tomar na semana seguinte.

Use linguagem direta e prática. Cite links ou identificadores dos posts analisados sempre que o Metricool fornecer esses dados.

## Revisão de encerramento

Antes de entregar, confira:

- Cada recomendação tem evidência ou está rotulada como hipótese?
- O calendário reflete os resultados reais e não uma frequência arbitrária?
- Cada plataforma recebeu adaptações próprias?
- O plano cabe na capacidade conhecida ou declara a premissa usada?
- Horários e datas estão fundamentados?
- Os testes têm critérios claros de avaliação?
- O plano evita repetir formatos consistentemente fracos sem uma justificativa experimental?
- Nenhuma publicação foi agendada ou alterada sem autorização explícita?

Se qualquer resposta indicar uma falha, corrija o plano antes de entregá-lo.
