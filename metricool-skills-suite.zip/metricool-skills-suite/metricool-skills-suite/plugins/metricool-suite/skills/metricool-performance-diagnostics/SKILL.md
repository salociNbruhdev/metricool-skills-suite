---
name: metricool-performance-diagnostics
description: Diagnostica o desempenho das contas conectadas ao Metricool, identifica conteúdos vencedores, gargalos, tendências, oportunidades e prioridades com base em evidências.
---

# Diagnóstico de desempenho das redes sociais

## Missão

Transformar dados coletados do Metricool em diagnóstico profundo, por rede e consolidado. Responda com evidências: o que está funcionando, o que não está, onde está o gargalo, quais padrões aparecem e o que merece teste.

## Princípio de qualidade

Não priorize velocidade. Faça cruzamentos, verifique denominadores, examine posts individuais e procure explicações alternativas. Uma conclusão sem evidência ou sem amostra suficiente deve ser chamada de hipótese.

## 1. Comece pela linha de base

Para cada marca e plataforma, registre:

- Seguidores/subscritores no início e fim do período, quando disponíveis.
- Crescimento absoluto e percentual.
- Alcance/impressões/visualizações.
- Interações por tipo.
- Engagement e sua fórmula, quando possível.
- Cliques/visitas/conversões relevantes.
- Número de publicações e frequência.
- Medianas e médias por publicação.
- Comparação com período anterior equivalente.

Fórmulas derivadas devem ser identificadas como cálculos do analista. Exemplo:

- Crescimento percentual = (valor final - valor inicial) / valor inicial × 100. Se o valor inicial for zero, não calcule percentual.
- Interações por publicação = total de interações / número de publicações elegíveis.
- Taxa de interação por alcance = interações / alcance × 100, somente se numerador e denominador forem referentes à mesma unidade e janela.

Não recalcule uma métrica com fórmula presumida se a plataforma fornecer uma definição própria sem antes registrar a diferença.

## 2. Diagnóstico por plataforma

Não trate todas as redes como se fossem iguais. Considere a intenção e o mecanismo de cada uma:

- Instagram: separar Feed, Reels, Stories e outros formatos. Examinar alcance, reproduções, interações, salvamentos, compartilhamentos, visitas ao perfil e crescimento, conforme disponíveis.
- TikTok: considerar visualizações, retenção/tempo de exibição, conclusão, compartilhamentos, comentários, favoritos e seguidores gerados, se disponíveis.
- YouTube: distinguir Shorts e vídeos longos; avaliar impressões, CTR, visualizações, duração média, retenção, horas assistidas e inscritos gerados, se disponíveis.
- Facebook: distinguir formatos e distribuição orgânica/paga quando possível.
- LinkedIn: examinar alcance/impressões, interações, cliques, seguidores e tipo de publicação.
- X: examinar impressões, engajamento, respostas, reposts, cliques e cadência, conforme disponíveis.
- Pinterest: observar impressões, salvamentos, cliques de saída e tráfego, se disponíveis.
- Threads/Bluesky/Twitch: usar apenas os campos disponíveis e interpretar de acordo com o formato próprio da plataforma.

## 3. Conteúdo vencedor e conteúdo fraco

Construa rankings separados por objetivo e formato, não apenas por volume absoluto. Identifique:

- Melhores conteúdos por alcance/visualizações.
- Melhores por taxa de interação ou engagement comparável.
- Melhores por compartilhamentos e salvamentos, quando disponíveis.
- Melhores por conversão, clique ou seguidor gerado, quando disponíveis.
- Piores conteúdos que tiveram exposição suficiente para avaliação.
- Conteúdos com alto alcance e baixa interação, que podem indicar desalinhamento entre promessa e entrega.
- Conteúdos com alcance baixo mas alta taxa de interação, que podem revelar um tema promissor com distribuição limitada.

Para cada exemplo inclua data, formato, tema, métricas principais, resultado relativo à mediana da conta e link/permalink se disponível. Evite chamar um post de "fracasso" apenas porque tem baixo volume bruto; considere o alcance e a maturidade da publicação.

## 4. Padrões e fatores de desempenho

Cruze resultados por:

- Formato e duração.
- Tema, pilar editorial e intenção do conteúdo.
- Gancho inicial, promessa, estrutura narrativa e CTA, se o texto/vídeo estiver acessível.
- Dia da semana e horário.
- Frequência e espaçamento das publicações.
- Séries e formatos recorrentes.
- Uso de áudio, hashtags, título, thumbnail ou capa, se disponível.
- Distribuição por rede e reaproveitamento de conteúdo.

Não infira causalidade a partir de correlações. Para horário, por exemplo, compare uma amostra razoável de posts e recomende teste A/B ou blocos alternados, não uma regra definitiva baseada em um único post.

## 5. Diagnóstico de funil

Quando as métricas permitirem, localize o gargalo:

- Distribuição: pouco alcance/impressões.
- Atenção: exposição existe, mas visualizações qualificadas ou retenção são baixas.
- Interesse: visualizações existem, mas interação/salvamentos/compartilhamentos não acompanham.
- Conversão: interesse existe, mas visitas, cliques, leads ou ações finais são baixas.

Não conclua sobre vendas ou receita se não houver dados de conversão ou atribuição. Separe objetivos de awareness, comunidade, tráfego e conversão.

## 6. Benchmark interno e contexto

Compare com o período anterior equivalente e com a mediana da própria conta. Não misture perfis de tamanhos, audiências ou objetivos muito diferentes em um só benchmark. Considere sazonalidade, campanhas, mudanças de plataforma e volume de publicação.

## 7. Saída do diagnóstico

Para cada plataforma, entregue:

1. Estado geral e tendência.
2. Indicadores-chave com variação.
3. O que está funcionando e evidências.
4. O que não está funcionando e evidências.
5. Conteúdos que exemplificam os padrões.
6. Gargalo principal e hipóteses alternativas.
7. Oportunidades de melhoria ordenadas por impacto provável.
8. Nível de confiança: alto, médio ou baixo, com justificativa.

Finalize com uma visão consolidada, mas não some dados incomparáveis entre plataformas. Destaque quais redes merecem mais investimento de tempo e quais exigem reformulação.
